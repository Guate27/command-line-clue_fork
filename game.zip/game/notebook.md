# Detective's Notebook

## Suspects
- [ ] The Police Officer
- [ ] The Tailor
- [ ] The Chef

## Weapons
- [ ] Brass Bell
- [ ] Leather Gloves
- [ ] Fountain Pen

## Notes
*Use this space to record your findings and deductions...*

Location of the crime is still unknown - the room must have been empty when it happened...
